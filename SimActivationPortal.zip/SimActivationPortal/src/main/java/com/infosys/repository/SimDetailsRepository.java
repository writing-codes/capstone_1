package com.infosys.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.infosys.entity.SimDetails;

@Repository
public interface SimDetailsRepository extends JpaRepository<SimDetails, Integer>{

	@Query("select l from SimDetails l where l.serviceNumber=?1 and l.simNumber=?2")
	Optional<SimDetails> checkForSimAndService(Long serviceNumber, Long simNumber);

}
