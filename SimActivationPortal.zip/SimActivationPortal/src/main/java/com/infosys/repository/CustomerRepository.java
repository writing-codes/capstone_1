package com.infosys.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.infosys.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long>{

	@Query("select s from Customer s where s.firstName=?1 and s.lastName=?2")
	Optional<Customer> checkForFirstAndLastName(String firstName, String lastName);

	
	@Query("select u from Customer u where u.uniqueIdNumber=?1")
	Optional<Customer> findByUniqueId(Long uniqueIdNumber);
	
}
