package com.infosys.repository;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.infosys.entity.CustomerIdentity;

@Repository
public interface CustomerIdentityRepository extends JpaRepository<CustomerIdentity, Long>{

	
	@Query("select t from CustomerIdentity t where t.dateOfbirth=?1 and t.emailAddress=?2")
	Optional<CustomerIdentity> checkForEmailAndDob(LocalDate dateOfbirth, String emailAddress);
	
	
}
