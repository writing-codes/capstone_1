package com.infosys.util;

public enum Constants {

		INVALID_SIM_DETAILS("simdetails.invalid"),
		INVALID_EMAIL_AND_DOB_DETAILS("customeridentity.invalid"),
		INVALID_FIRST_AND_LAST_NAME("customer.invalid"),
		INVALID_CUSTOMER_EMAIL("customervalidation.email.Invalid"),
		INVALID_FIRSTLAST_NAME("customer.firstlast.invalid"), 
		INVALID_DOB("customer.dob.invalid"),
		ALL_DATA_MANDATORY("customer.all.mandatory");
		

		private final String type;

		private Constants(String type) {
			this.type = type;
		}

		@Override
		public String toString() {
			return this.type;
		}
}
