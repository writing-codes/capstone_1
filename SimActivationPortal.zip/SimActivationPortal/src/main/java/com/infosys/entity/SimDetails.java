package com.infosys.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@JsonIgnoreProperties(value={"simOffers"})
public class SimDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer simId;
	
	private Long serviceNumber;
	
	private Long simNumber;
	
	private String simStatus;

	@JsonIgnore
	@OneToMany(mappedBy = "simDetails")
	List<SimOffers> simOffers;
	
	public SimDetails() {}

	public SimDetails(Integer simId,Long serviceNumber,Long simNumber,String simStatus) {
		this.simId = simId;
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
		this.simStatus = simStatus;
	}

	public Integer getsimId() {
		return simId;
	}

	public void setsimId(Integer simId) {
		this.simId = simId;
	}

	public Long getServiceNumber() {
		return serviceNumber;
	}

	public void setServiceNumber(Long serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public Long getSimNumber() {
		return simNumber;
	}

	public void setSimNumber(Long simNumber) {
		this.simNumber = simNumber;
	}

	public String getSimStatus() {
		return simStatus;
	}

	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}

	public List<SimOffers> getsimOffers() {
		return simOffers;
	}

	public void setsimOffers(List<SimOffers> simOffers) {
		this.simOffers = simOffers;
	}

	@Override
	public String toString() {
		return "SimDetails [simId=" + simId + ", serviceNumber=" + serviceNumber + ", simNumber=" + simNumber
				+ ", simStatus=" + simStatus + "]";
	}

	
	
	
	
	
}
