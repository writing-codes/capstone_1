package com.infosys.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long uniqueIdNumber;
	
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private LocalDate dateOfbirth;
	
	private String emailAddress;
	
	private String firstName;
	
	private String lastName;
	
	private String idType;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customerAddress_addressId" ,nullable = false)
	@JsonIgnore
	private CustomerAddress customerAddress;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "simId" ,nullable = false)
	@JsonIgnore
	private SimDetails simDetails;

	private String state;

	
	public Customer() {}


	public Customer(Long uniqueIdNumber, LocalDate dateOfbirth, String emailAddress, String firstName, String lastName,
			String idType, CustomerAddress customerAddress, SimDetails simDetails, String state) {
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfbirth = dateOfbirth;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.idType = idType;
		this.customerAddress = customerAddress;
		this.simDetails = simDetails;
		this.state = state;
	}


	public Long getUniqueIdNumber() {
		return uniqueIdNumber;
	}


	public void setUniqueIdNumber(Long uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}


	public LocalDate getDateOfbirth() {
		return dateOfbirth;
	}


	public void setDateOfbirth(LocalDate dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}


	public String getEmailAddress() {
		return emailAddress;
	}


	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getIdType() {
		return idType;
	}


	public void setIdType(String idType) {
		this.idType = idType;
	}


	public CustomerAddress getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(CustomerAddress customerAddress) {
		this.customerAddress = customerAddress;
	}


	public SimDetails getSimDetails() {
		return simDetails;
	}


	public void setSimDetails(SimDetails simDetails) {
		this.simDetails = simDetails;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	@Override
	public String toString() {
		return "Customer [uniqueIdNumber=" + uniqueIdNumber + ", dateOfbirth=" + dateOfbirth + ", emailAddress="
				+ emailAddress + ", firstName=" + firstName + ", lastName=" + lastName + ", idType=" + idType
				+ ", customerAddress=" + customerAddress + ", simDetails=" + simDetails + ", state=" + state + "]";
	}

	
	
}
