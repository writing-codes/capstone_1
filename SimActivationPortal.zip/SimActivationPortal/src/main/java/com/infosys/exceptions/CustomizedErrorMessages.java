package com.infosys.exceptions;

public class CustomizedErrorMessages extends Exception {
 
	private static final long serialVersionUID = 1L;
	public CustomizedErrorMessages(String errors) {
		super(errors);
	}
}
