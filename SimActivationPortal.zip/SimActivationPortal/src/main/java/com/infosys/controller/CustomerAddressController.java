package com.infosys.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.CustomerAddressDTO;
import com.infosys.exceptions.CustomizedErrorMessages;
import com.infosys.service.CustomerAddressService;

@RestController
@RequestMapping("/customerAddress")
public class CustomerAddressController {
	
	private CustomerAddressService customerAddressService;
	
	@Autowired
	public void setCustomerAddressService(CustomerAddressService customerAddressService) {
		this.customerAddressService = customerAddressService;
	}
	
	@PutMapping(value = "/Update_Customer_Address", consumes = "application/json") 
	public ResponseEntity<Object> updateOrAddCustomer (@Valid @RequestBody CustomerAddressDTO customerAddressDTO) throws CustomizedErrorMessages
	{
		return ResponseEntity.status(HttpStatus.OK).body(customerAddressService.updateOrAddCustomer(customerAddressDTO));
	}
}
