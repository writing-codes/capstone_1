package com.infosys.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.CustomerDTO;
import com.infosys.exceptions.CustomizedErrorMessages;
import com.infosys.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	private CustomerService customerService;
	
	@Autowired
	public void setCustomerService(CustomerService customerService) {
		this.customerService=customerService;
	}
	
	
	
	@PostMapping("/Customer_Personal_Details")
	public ResponseEntity<Object> checkFirstAndLastName(@RequestBody @Valid CustomerDTO customerDTO) throws CustomizedErrorMessages{
		
		HashMap<String, Object> customers = customerService.checkFirstAndLastName(customerDTO);
		return ResponseEntity.ok(customers);
	}
	
	
	
	@PostMapping("Customer_ID_Proof_Validation")
	public ResponseEntity<Object> checkIdProof(@RequestBody @Valid CustomerDTO customerDTO ) throws CustomizedErrorMessages
	{
		return ResponseEntity.status(HttpStatus.CREATED).body(customerService.checkIdProof(customerDTO));
		
	}
}
