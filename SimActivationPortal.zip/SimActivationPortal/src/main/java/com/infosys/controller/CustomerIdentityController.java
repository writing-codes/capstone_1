package com.infosys.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.CustomerIdentiyDTO;
import com.infosys.exceptions.CustomizedErrorMessages;
import com.infosys.service.CustomerIdentityService;

@RestController
@RequestMapping("/customerIdentity")
public class CustomerIdentityController {

	private CustomerIdentityService customerIdentityService;
	
	@Autowired
	public void setCustomerService(CustomerIdentityService customerIdentityService) {
		this.customerIdentityService=customerIdentityService;
	}
	
	
	@PostMapping("/Customer_Basics_Details")
	public ResponseEntity<String> checkEmailAndDob(@RequestBody @Valid CustomerIdentiyDTO customerIdentiyDTO) throws CustomizedErrorMessages{
		
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(customerIdentityService.checkEmailAndDob(customerIdentiyDTO));
	}
}
