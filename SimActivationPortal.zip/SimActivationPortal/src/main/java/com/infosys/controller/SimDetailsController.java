package com.infosys.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.SimDetailsDTO;
import com.infosys.exceptions.CustomizedErrorMessages;
import com.infosys.service.SimDetailsService;

@RestController
@RequestMapping("/SimDetails")
public class SimDetailsController {
	
	private SimDetailsService simDetailsService;
	
	@Autowired
	public void setSimDetailsService(SimDetailsService simDetailsService) {
		this.simDetailsService = simDetailsService;
	}
	
	@PostMapping("/verify")
	public ResponseEntity<Object> checkSimAndService(@RequestBody @Valid SimDetailsDTO simDetailsDTO) throws CustomizedErrorMessages{
		
		HashMap<String, Object> simOffers = simDetailsService.checkSimAndService(simDetailsDTO);
		return ResponseEntity.ok(simOffers);
	}
	
}
