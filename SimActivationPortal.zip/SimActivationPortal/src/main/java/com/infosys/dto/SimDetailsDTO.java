package com.infosys.dto;

import javax.validation.constraints.Digits;

import com.infosys.entity.SimDetails;

public class SimDetailsDTO {

	private Integer simId;
	
	@Digits(integer = 10, fraction = 0, message = "{simdetails.service.invalid}")
	private Long serviceNumber;
	
	@Digits(integer = 13, fraction = 0, message = "{simdetails.sim.invalid}")
	private Long simNumber;
	
	private String simStatus;


	public SimDetailsDTO() {}

	public SimDetailsDTO(Integer simId,
			@Digits(integer = 10, fraction = 0, message = "{simdetails.service.invalid}") Long serviceNumber,
			@Digits(integer = 13, fraction = 0, message = "{simdetails.sim.invalid}") Long simNumber,
			String simStatus) {
		this.simId = simId;
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
		this.simStatus = simStatus;
	}

	public Integer getsimId() {
		return simId;
	}

	public void setsimId(Integer simId) {
		this.simId = simId;
	}

	public Long getServiceNumber() {
		return serviceNumber;
	}

	public void setServiceNumber(Long serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public Long getSimNumber() {
		return simNumber;
	}

	public void setSimNumber(Long simNumber) {
		this.simNumber = simNumber;
	}

	public String getSimStatus() {
		return simStatus;
	}

	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}


	@Override
	public String toString() {
		return "SimDetailsDTO [simId=" + simId + ", serviceNumber=" + serviceNumber + ", simNumber=" + simNumber
				+ ", simStatus=" + simStatus + "]";
	}

	public static SimDetails convertDTOToEntity(SimDetailsDTO simDetailsDTO) {
		SimDetails simDetails = new SimDetails();
		simDetails.setsimId(simDetailsDTO.getsimId());
		simDetails.setServiceNumber(simDetailsDTO.getServiceNumber());
		simDetails.setSimNumber(simDetailsDTO.getSimNumber());
		simDetails.setSimStatus(simDetailsDTO.getSimStatus());
		return simDetails;
	}

	
	
}