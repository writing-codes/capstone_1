package com.infosys.dto;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.infosys.entity.CustomerAddress;

public class CustomerAddressDTO {
	
	private Integer addressId;
	
	@Length(max = 15,message = "{customeraddress.address.must}")
	private String address;
	
	@Pattern(regexp = "^[A-Za-z0-9\s]*$",message = "{customeraddress.ctystate.must}")
	private String city;
	
	@Digits(integer = 6,fraction = 0,message = "{customeraddress.pincode.must}")
	private Integer pincode;
	
	@Pattern(regexp = "^[A-Za-z0-9\s]*$",message = "{customeraddress.ctystate.must}")
	private String state;

	public CustomerAddressDTO() {}

	public CustomerAddressDTO(Integer addressId,
			@Length(max = 15, message = "{customeraddress.address.must}") String address, String city,
			@Digits(integer = 6, fraction = 0, message = "{customeraddress.pincode.must}") Integer pincode,
			@Pattern(regexp = "^[A-Za-z0-9 ]*$", message = "{customeraddress.ctystate.must}") String state) {
		this.addressId = addressId;
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "CustomerAddressDTO [addressId=" + addressId + ", address=" + address + ", city=" + city + ", pincode="
				+ pincode + ", state=" + state + "]";
	}
	
	public static CustomerAddress convertDTOToEntity(CustomerAddressDTO customerAddressDTO) {
		CustomerAddress customerAddress = new CustomerAddress();
		customerAddress.setAddressId(customerAddressDTO.getAddressId());
		customerAddress.setAddress(customerAddressDTO.getAddress());
		customerAddress.setCity(customerAddressDTO.getCity());
		customerAddress.setPincode(customerAddressDTO.getPincode());
		customerAddress.setState(customerAddressDTO.getState());
		return customerAddress;
	}
	
}
