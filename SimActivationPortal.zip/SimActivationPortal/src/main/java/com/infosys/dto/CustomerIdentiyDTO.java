package com.infosys.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.infosys.entity.CustomerIdentity;

public class CustomerIdentiyDTO {
	
	private Long uniqueIdNumber;
	
	@NotNull(message = "{customeridentity.dob.must}")
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private LocalDate dateOfbirth;
	
	private String firstName;
	
	private String lastName;
	
	@NotBlank(message = "{customeridentity.email.must}")
	@Email(message = "{customer.email.invalid}")
	private String emailAddress;
	
	private String state;

	public CustomerIdentiyDTO() {}

	public CustomerIdentiyDTO(Long uniqueIdNumber,
			@NotNull(message = "{customeridentity.dob.must}") LocalDate dateOfbirth, String firstName, String lastName,
			@NotBlank(message = "{customeridentity.email.must}") @Email(message = "{customer.email.invalid}") String emailAddress,
			String state) {
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfbirth = dateOfbirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.state = state;
	}

	public Long getUniqueIdNumber() {
		return uniqueIdNumber;
	}

	public void setUniqueIdNumber(Long uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}

	public LocalDate getDateOfbirth() {
		return dateOfbirth;
	}

	public void setDateOfbirth(LocalDate dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "CustomerIdentiyDTO [uniqueIdNumber=" + uniqueIdNumber + ", dateOfbirth=" + dateOfbirth + ", firstName="
				+ firstName + ", lastName=" + lastName + ", emailAddress=" + emailAddress + ", state=" + state + "]";
	}
	
	public static CustomerIdentity convertDTOToEntity(CustomerIdentiyDTO customerIdentiyDTO) {
		CustomerIdentity customerIdentity = new CustomerIdentity();
		customerIdentity.setUniqueIdNumber(customerIdentiyDTO.getUniqueIdNumber());
		customerIdentity.setDateOfbirth(customerIdentiyDTO.getDateOfbirth());
		customerIdentity.setFirstName(customerIdentiyDTO.getFirstName());
		customerIdentity.setLastName(customerIdentiyDTO.getLastName());
		customerIdentity.setEmailAddress(customerIdentiyDTO.getEmailAddress());
		customerIdentity.setState(customerIdentiyDTO.getState());
		return customerIdentity;
	}
}
