package com.infosys.dto;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.infosys.entity.Customer;
import com.infosys.entity.CustomerAddress;
import com.infosys.entity.SimDetails;

public class CustomerDTO {
	
	@NotNull(message = "{customer.uniqueno.must}")
	@Digits(integer = 16, fraction = 0, message = "{customer.uniqueno.must}")
	private Long uniqueIdNumber;
	
	@NotNull(message = "{customeridentity.dob.must}")
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private LocalDate dateOfbirth;
	
	@NotBlank(message = "{customeridentity.email.must}")
	@Email(message = "{customer.email.invalid}")
	private String emailAddress;
	
	@Pattern(regexp = "^[A-Za-z]*$",message = "{customer.firstname.must}")
	@Length(max = 15, message = "{customer.firstname.must}")
	private String firstName;
	
	@Pattern(regexp = "^[A-Za-z]*$",message = "{customer.lastname.must}")
	@Length(max = 15, message = "{customer.lastname.must}")
	private String lastName;
	
	private String idType;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customerAddress_addressId" ,nullable = false)
	@JsonIgnore
	private CustomerAddress customerAddress;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "simId" ,nullable = false)
	@JsonIgnore
	private SimDetails simDetails;

	private String state;

	public CustomerDTO() {}

	public CustomerDTO(
			@NotNull(message = "{customer.uniqueno.must}") @Digits(integer = 16, fraction = 0, message = "{customer.uniqueno.must}") Long uniqueIdNumber,
			@NotNull(message = "{customeridentity.dob.must}") LocalDate dateOfbirth,
			@Email(message = "{customer.email.invalid}") String emailAddress,
			@Pattern(regexp = "^[A-Za-z]*$", message = "{customer.firstname.must}") @Length(max = 15, message = "{customer.firstname.must}") String firstName,
			@Pattern(regexp = "^[A-Za-z]*$", message = "{customer.lastname.must}") @Length(max = 15, message = "{customer.lastname.must}") String lastName,
			String idType, CustomerAddress customerAddress, SimDetails simDetails, String state) {
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfbirth = dateOfbirth;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.idType = idType;
		this.customerAddress = customerAddress;
		this.simDetails = simDetails;
		this.state = state;
	}

	public Long getUniqueIdNumber() {
		return uniqueIdNumber;
	}

	public void setUniqueIdNumber(Long uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}

	public LocalDate getDateOfbirth() {
		return dateOfbirth;
	}

	public void setDateOfbirth(LocalDate dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public CustomerAddress getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(CustomerAddress customerAddress) {
		this.customerAddress = customerAddress;
	}

	public SimDetails getSimDetails() {
		return simDetails;
	}

	public void setSimDetails(SimDetails simDetails) {
		this.simDetails = simDetails;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "CustomerDTO [uniqueIdNumber=" + uniqueIdNumber + ", dateOfbirth=" + dateOfbirth + ", emailAddress="
				+ emailAddress + ", firstName=" + firstName + ", lastName=" + lastName + ", idType=" + idType
				+ ", customerAddress=" + customerAddress + ", simDetails=" + simDetails + ", state=" + state + "]";
	}
	
	public static Customer convertDTOToEntity(CustomerDTO customerDTO) {
		Customer customer = new Customer();
		customer.setUniqueIdNumber(customerDTO.getUniqueIdNumber());
		customer.setDateOfbirth(customerDTO.getDateOfbirth());
		customer.setEmailAddress(customerDTO.getEmailAddress());
		customer.setFirstName(customerDTO.getFirstName());
		customer.setLastName(customerDTO.getLastName());
		customer.setIdType(customerDTO.getIdType());
		customer.setCustomerAddress(customerDTO.getCustomerAddress());
		customer.setSimDetails(customerDTO.getSimDetails());
		customer.setState(customerDTO.getState());
		return customer;
	}
	
}
