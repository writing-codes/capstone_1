package com.infosys.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.infosys.dto.SimDetailsDTO;
import com.infosys.entity.SimDetails;
import com.infosys.entity.SimOffers;
import com.infosys.exceptions.CustomizedErrorMessages;
import com.infosys.repository.SimDetailsRepository;
import com.infosys.util.Constants;

@Service
@PropertySource("classpath:ValidationMessages.properties")
public class SimDetailsService {

	private SimDetailsRepository simDetailsRepository;
	
	@Autowired
	private Environment environment;
	
	@Autowired
	private void setSimDetailsRepository(SimDetailsRepository simDetailsRepository) {
		this.simDetailsRepository=simDetailsRepository;
	}
	
	public HashMap<String, Object> checkSimAndService(@Valid SimDetailsDTO simDetailsDTO) throws CustomizedErrorMessages 
	{
		
		Long serviceLong = simDetailsDTO.getServiceNumber();
		Long simLong = simDetailsDTO.getSimNumber();
		
		Optional<SimDetails> simDetailsOptional = simDetailsRepository.checkForSimAndService(serviceLong,simLong);
		
		if(simDetailsOptional.isPresent()) 
		{
			String tempString = new String();
			if(simDetailsOptional.get().getSimStatus().equals("active")) 
			{
				tempString = "SIM already active";
			}
			else 
			{
				tempString = "SIM is inactive";
			}
				
			List<SimOffers> sim_offers = simDetailsOptional.get().getsimOffers();
			HashMap<String, Object> hashMap = new HashMap<>();
			hashMap.put("Sim_Offers", sim_offers);
			hashMap.put("Sim_Status", tempString );
			return hashMap;
		}
		else 
		{
			throw new CustomizedErrorMessages(environment.getProperty(Constants.INVALID_SIM_DETAILS.toString()));
		}
	}
	
	
}
