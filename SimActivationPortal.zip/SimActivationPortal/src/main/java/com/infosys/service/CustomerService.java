package com.infosys.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.infosys.dto.CustomerDTO;
import com.infosys.entity.Customer;
import com.infosys.exceptions.CustomizedErrorMessages;
import com.infosys.repository.CustomerRepository;
import com.infosys.util.Constants;

@Service
@PropertySource("classpath:ValidationMessages.properties")
public class CustomerService {
	
	private CustomerRepository customerRepository;
		
	@Autowired
	private Environment environment;
		
	@Autowired
	private void setCustomerRepository(CustomerRepository customerRepository) {
		this.customerRepository=customerRepository;
	}
		
	
	public HashMap<String, Object> checkFirstAndLastName(@Valid CustomerDTO customerDTO) throws CustomizedErrorMessages {
		
		String firstname = customerDTO.getFirstName();
		String lastname = customerDTO.getLastName();
		String email = customerDTO.getEmailAddress();
		
		Optional<Customer> customerOptional = customerRepository.checkForFirstAndLastName(firstname,lastname);
		
		if(customerOptional.isPresent()) {
			String emailValidation = "";
			if(customerOptional.get().getEmailAddress().equals(email))
			{
				emailValidation="Success";
			}
			else {
				throw new CustomizedErrorMessages(environment.getProperty(Constants.INVALID_CUSTOMER_EMAIL.toString()));
			}
			List<Customer> cList = new ArrayList<>();
			customerOptional.ifPresent(cList::add);
				
			HashMap<String, Object> hashMap = new HashMap<>();
			hashMap.put("Customer", cList);
			hashMap.put("message", emailValidation );
			return hashMap;
		}
		else {
			throw new CustomizedErrorMessages(environment.getProperty(Constants.INVALID_FIRST_AND_LAST_NAME.toString()));
		}
		
	}
	
	
	
	
	
	public Object checkIdProof(@Valid CustomerDTO customerDTO) throws CustomizedErrorMessages 
	{
		
		Long uid = customerDTO.getUniqueIdNumber();
		String fname = customerDTO.getFirstName();
		String lname = customerDTO.getLastName();
		LocalDate dob = customerDTO.getDateOfbirth();
		
		Optional<Customer> custIdentity = customerRepository.findByUniqueId(uid);
		
		if(!custIdentity.isEmpty()) 
		{
			if(custIdentity.get().getFirstName().toLowerCase().equals(fname.toLowerCase()) 
					&& custIdentity.get().getLastName().toLowerCase().equals(lname.toLowerCase())) 
			{
				if (custIdentity.get().getDateOfbirth().equals(dob)) 
				{
					Customer customer = custIdentity.get();
					customer.getSimDetails().setSimStatus("active");
					customerRepository.saveAndFlush(customer);
					return "Successful Sim Activation";
				}
				else 
				{
					throw new CustomizedErrorMessages(environment.getProperty(Constants.INVALID_DOB.toString()));
				}
			}
			else 
			{
				throw new CustomizedErrorMessages(environment.getProperty(Constants.INVALID_FIRSTLAST_NAME.toString()));
			}
		}
		else 
		{
			throw new CustomizedErrorMessages(environment.getProperty(Constants.ALL_DATA_MANDATORY.toString()));
		}
	}

	

}
