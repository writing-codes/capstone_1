package com.infosys.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.dto.CustomerAddressDTO;
import com.infosys.entity.CustomerAddress;
import com.infosys.repository.CustomerAddressRepository;

@Service
public class CustomerAddressService {

	private CustomerAddressRepository customerAddressRepository;

	@Autowired
	public void setCustomerAddressRepository(CustomerAddressRepository customerAddressRepository) {
		this.customerAddressRepository = customerAddressRepository;
	}
	
	
	public Object updateOrAddCustomer(@Valid CustomerAddressDTO customerAddressDTO) {
		
		Integer addressIdInteger = customerAddressDTO.getAddressId(); 
		String addressString = customerAddressDTO.getAddress();
		String cityString = customerAddressDTO.getCity();
		Integer pincodeInteger = customerAddressDTO.getPincode();
		String stateString = customerAddressDTO.getState();
		
		
		Optional<CustomerAddress> custAddOptional = customerAddressRepository.checkAddressDetails(addressIdInteger);
		
		if(custAddOptional.isPresent())
		{
			CustomerAddress customerAddress = null;
			customerAddress = custAddOptional.get();
			customerAddress.setAddress(addressString);
			customerAddress.setCity(cityString);
			customerAddress.setPincode(pincodeInteger);
			customerAddress.setState(stateString);
			customerAddressRepository.saveAndFlush(customerAddress);
			return customerAddress;
		}
		else {
			CustomerAddress customerAddress = new CustomerAddress();
			customerAddress.setAddressId(addressIdInteger);
			customerAddress.setAddress(addressString);
			customerAddress.setCity(cityString);
			customerAddress.setPincode(pincodeInteger);
			customerAddress.setState(stateString);
			customerAddressRepository.save(customerAddress);
			return customerAddress;
		}
		
	}
}
