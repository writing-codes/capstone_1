package com.infosys.service;

import java.time.LocalDate;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.infosys.dto.CustomerIdentiyDTO;
import com.infosys.entity.CustomerIdentity;
import com.infosys.exceptions.CustomizedErrorMessages;
import com.infosys.repository.CustomerIdentityRepository;
import com.infosys.util.Constants;

@Service
public class CustomerIdentityService {
	
	private CustomerIdentityRepository customerIdentityRepository;
	
	@Autowired
	private Environment environment;
	
	@Autowired
	private void setCustomerIdentityRepository(CustomerIdentityRepository customerIdentityRepository) {
		this.customerIdentityRepository=customerIdentityRepository;
	}

	public String checkEmailAndDob(@Valid CustomerIdentiyDTO customerIdentiyDTO) throws CustomizedErrorMessages {
		
		LocalDate dobLocalDate = customerIdentiyDTO.getDateOfbirth();
		String emailString = customerIdentiyDTO.getEmailAddress();
		
		Optional<CustomerIdentity> custOptional = customerIdentityRepository.checkForEmailAndDob(dobLocalDate,emailString);
		
		if(custOptional.isPresent()) {
			
			return "SUCCESS";
		}
		else {
			throw new CustomizedErrorMessages(environment.getProperty(Constants.INVALID_EMAIL_AND_DOB_DETAILS.toString()));
		}
		
	}
}
