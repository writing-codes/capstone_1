package com.telecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimActivationPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
